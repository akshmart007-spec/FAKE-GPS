package com.fakegps.lock

import android.Manifest
import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    companion object {
        // >>> Set your GitHub "username/repo" here (for in-app update). Repo must be PUBLIC.
        const val UPDATE_REPO = "USERNAME/REPO"
    }

    private lateinit var map: MapView
    private lateinit var prefs: SharedPreferences
    private lateinit var drawer: DrawerLayout
    private lateinit var drawerList: LinearLayout
    private lateinit var etLat: EditText
    private lateinit var etLng: EditText
    private lateinit var etSearch: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var btnLock: Button
    private lateinit var btnWalk: Button
    private lateinit var panelMove: View
    private lateinit var seek: SeekBar

    private var marker: Marker? = null
    private val waypoints = mutableListOf<GeoPoint>()
    private val wpMarkers = mutableListOf<Marker>()
    private var routeLine: Polyline? = null
    private var loopRoute = false

    private var lat = 28.6139
    private var lng = 77.2090
    private var speedKmh = 5
    private var walking = false
    private var ticking = false
    private var joyN = 0.0
    private var joyE = 0.0
    private var totalM = 0.0

    private var roam = false
    private var roamRadius = 30
    private var roamCenter: GeoPoint? = null
    private var roamTarget: GeoPoint? = null

    private val ui = Handler(Looper.getMainLooper())

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) startMock()
            else toast("Location permission is required")
        }

    private val locPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) useMyLocation() else toast("Location permission needed")
        }

    private val moveTick = object : Runnable {
        override fun run() {
            if (stepMove()) ui.postDelayed(this, 500)
            else {
                ticking = false
                prefs.edit().putFloat("speed", 0f).apply()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osm")
            osmdroidTileCache = File(cacheDir, "osm/tiles")
        }
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("fakegps", MODE_PRIVATE)
        lat = prefs.getString("lat", "28.6139")!!.toDouble()
        lng = prefs.getString("lng", "77.2090")!!.toDouble()
        prefs.edit().putFloat("speed", 0f).apply()

        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.drawerList)
        etLat = findViewById(R.id.etLat)
        etLng = findViewById(R.id.etLng)
        etSearch = findViewById(R.id.etSearch)
        tvStatus = findViewById(R.id.tvStatus)
        tvSpeed = findViewById(R.id.tvSpeed)
        btnLock = findViewById(R.id.btnLock)
        btnWalk = findViewById(R.id.btnWalk)
        panelMove = findViewById(R.id.panelMove)
        seek = findViewById(R.id.seekSpeed)
        map = findViewById(R.id.map)

        map.setMultiTouchControls(true)
        map.controller.setZoom(15.0)
        applyMapType()
        applyKeepOn()
        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                if (MockLocationService.running) toast("Turn lock OFF first, then change location")
                else setPoint(p.latitude, p.longitude, false)
                return true
            }
            override fun longPressHelper(p: GeoPoint): Boolean {
                addWaypoint(p)
                return true
            }
        }))
        setPoint(lat, lng, true)

        findViewById<Button>(R.id.btnMenu).setOnClickListener { openMenu() }
        findViewById<Button>(R.id.btnGo).setOnClickListener { goToTyped() }
        findViewById<Button>(R.id.btnSearch).setOnClickListener { searchPlace() }
        etSearch.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { searchPlace(); true } else false
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveFavorite() }
        findViewById<Button>(R.id.btnFav).setOnClickListener { showFavorites() }
        findViewById<Button>(R.id.btnMove).setOnClickListener { toggleMovePanel() }
        btnLock.setOnClickListener { toggleLock() }

        bindJoy(R.id.btnUp, 1.0, 0.0)
        bindJoy(R.id.btnDown, -1.0, 0.0)
        bindJoy(R.id.btnLeft, 0.0, -1.0)
        bindJoy(R.id.btnRight, 0.0, 1.0)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                speedKmh = p + 1
                tvSpeed.text = "Speed: $speedKmh km/h"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        seek.progress = 4

        btnWalk.setOnClickListener { toggleWalk() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) drawer.closeDrawers()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        checkUpdate(true)
    }

    // =====================================================================
    //  HAMBURGER MENU (drawer) - saare features yahan hain
    // =====================================================================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun openMenu() {
        buildDrawer()
        drawer.openDrawer(GravityCompat.START)
    }

    private fun addHeader(t: String) {
        drawerList.addView(TextView(this).apply {
            text = t.uppercase(Locale.getDefault())
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.teal))
            setPadding(dp(20), dp(18), dp(16), dp(4))
        })
    }

    private fun addItem(label: String, close: Boolean = true, action: () -> Unit) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 15f
        tv.setPadding(dp(20), dp(12), dp(16), dp(12))
        val tvv = TypedValue()
        this@MainActivity.theme.resolveAttribute(android.R.attr.selectableItemBackground, tvv, true)
        tv.setBackgroundResource(tvv.resourceId)
        tv.isClickable = true
        tv.setOnClickListener {
            if (close) drawer.closeDrawers()
            action()
        }
        drawerList.addView(tv)
    }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private fun buildDrawer() {
        drawerList.removeAllViews()
        val head = TextView(this)
        head.text = "FakeGPS Lock\nversion ${BuildConfig.VERSION_NAME}"
        head.textSize = 20f
        head.setTextColor(Color.WHITE)
        head.setBackgroundColor(ContextCompat.getColor(this, R.color.navy))
        head.setPadding(dp(20), dp(32), dp(16), dp(18))
        drawerList.addView(head)

        addHeader("Lock")
        addItem(if (MockLocationService.running) "Turn lock OFF" else "Turn lock ON") { toggleLock() }
        addItem("Auto-stop timer: " + (prefs.getInt("autostop", 0).let { if (it == 0) "off" else "$it min" })) { showTimer() }
        addItem("Setup check (permission / mock app)") { showSetupCheck() }

        addHeader("Choose location")
        addItem("Search place name") {
            etSearch.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
        }
        addItem("Go to my real location") { useMyLocation() }
        addItem("Center map on pin") { map.controller.animateTo(GeoPoint(lat, lng)) }
        addItem("Save favorite") { saveFavorite() }
        addItem("Favorites list") { showFavorites() }
        addItem("Recent history") { showHistory() }
        addItem("Favorites export (clipboard)") { exportFavorites() }
        addItem("Favorites import (clipboard)") { importFavorites() }

        addHeader("Movement")
        addItem("Joystick panel: " + (if (panelMove.visibility == View.VISIBLE) "open (currently open)" else "open")) { toggleMovePanel() }
        addItem("Speed preset (walk / run / cycle / car)") { showSpeedPresets() }
        addItem(if (walking) "Stop route walk" else "Start route walk") { toggleWalk() }
        addItem("Route points: ${waypoints.size}  (long-press on map to add)", close = false) {
            toast("Long-press on map to add route point")
        }
        addItem("Route loop: " + onOff(loopRoute), close = false) {
            loopRoute = !loopRoute
            buildDrawer()
        }
        addItem("Clear route") { clearRoute() }
        addItem("Roam mode (wander nearby): " + onOff(roam), close = false) {
            setRoam(!roam)
            buildDrawer()
        }
        addItem("Roam radius: $roamRadius m") { showRoamRadius() }

        addHeader("Realism")
        addItem("Realistic drift: " + onOff(prefs.getBoolean("jitter", false)), close = false) {
            prefs.edit().putBoolean("jitter", !prefs.getBoolean("jitter", false)).apply()
            buildDrawer()
        }
        addItem("GPS accuracy: ${prefs.getInt("acc", 3)} m") { showAccuracy() }
        addItem("Altitude: ${prefs.getInt("alt", 0)} m") { showAltitude() }

        addHeader("Map")
        addItem("Map type (standard / satellite / topo)") { showMapType() }
        addItem("Dark map: " + onOff(prefs.getBoolean("darkmap", false)), close = false) {
            prefs.edit().putBoolean("darkmap", !prefs.getBoolean("darkmap", false)).apply()
            applyMapType()
            buildDrawer()
        }
        addItem("Keep screen ON: " + onOff(prefs.getBoolean("keepon", false)), close = false) {
            prefs.edit().putBoolean("keepon", !prefs.getBoolean("keepon", false)).apply()
            applyKeepOn()
            buildDrawer()
        }

        addHeader("Share / tools")
        addItem("Copy coordinates") { copyCoords() }
        addItem("Share location link") { shareLink() }
        addItem("Open in Google Maps") { openMaps() }
        addItem("Show session distance") { showDistance() }

        addHeader("Settings / help")
        addItem("Mock location app setting") { showMockHelp() }
        addItem("Battery setting (prevent service kill)") { openBatterySettings() }
        addItem("Check for update") { checkUpdate(false) }
        addItem("How to use") { showHowTo() }
    }

    // ---------- map / location ----------
    private fun setPoint(la: Double, ln: Double, center: Boolean) {
        lat = la; lng = ln
        etLat.setText(String.format(Locale.US, "%.6f", la))
        etLng.setText(String.format(Locale.US, "%.6f", ln))
        prefs.edit().putString("lat", la.toString()).putString("lng", ln.toString()).apply()
        val gp = GeoPoint(la, ln)
        if (marker == null) {
            marker = Marker(map).apply {
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                title = "Fake location"
            }
            map.overlays.add(marker)
        }
        marker!!.position = gp
        if (center) map.controller.setCenter(gp) else map.controller.animateTo(gp)
        map.invalidate()
        refreshUi()
    }

    private fun goTo(la: Double, ln: Double) {
        if (MockLocationService.running) toast("Turn lock OFF first")
        else setPoint(la, ln, true)
    }

    private fun goToTyped() {
        var raw = etLat.text.toString().trim()
        var rawLng = etLng.text.toString().trim()
        if (raw.contains(",")) {
            val parts = raw.split(",")
            raw = parts[0].trim()
            rawLng = parts.getOrElse(1) { "" }.trim()
        }
        val la = raw.toDoubleOrNull()
        val ln = rawLng.toDoubleOrNull()
        if (la == null || ln == null || la !in -90.0..90.0 || ln !in -180.0..180.0) {
            toast("Enter valid latitude / longitude"); return
        }
        goTo(la, ln)
    }

    private fun searchPlace() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) { toast("Enter a place name"); return }
        if (MockLocationService.running) { toast("Turn lock OFF first"); return }
        toast("Searching…")
        thread {
            try {
                val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" +
                    URLEncoder.encode(q, "UTF-8")
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("User-Agent", "FakeGPSLock/1.0 (android app)")
                val arr = JSONArray(c.inputStream.bufferedReader().readText())
                runOnUiThread {
                    if (arr.length() == 0) toast("Place not found")
                    else {
                        val o = arr.getJSONObject(0)
                        setPoint(o.getString("lat").toDouble(), o.getString("lon").toDouble(), true)
                        map.controller.setZoom(16.0)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Search failed: ${e.message}") }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun useMyLocation() {
        if (MockLocationService.running) { toast("Lock is ON, turn it OFF first"); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            locPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
            val b = best
            if (l != null && (b == null || l.accuracy < b.accuracy)) best = l
        }
        val found = best
        if (found == null) toast("Real location not available yet. Open Maps app once to get location")
        else setPoint(found.latitude, found.longitude, true)
    }

    // ---------- map type / dark / screen on ----------
    private fun applyMapType() {
        map.setTileSource(
            when (prefs.getInt("maptype", 0)) {
                1 -> TileSourceFactory.USGS_SAT
                2 -> TileSourceFactory.OpenTopo
                else -> TileSourceFactory.MAPNIK
            }
        )
        map.overlayManager.tilesOverlay.setColorFilter(
            if (prefs.getBoolean("darkmap", false)) TilesOverlay.INVERT_COLORS else null
        )
        map.invalidate()
    }

    private fun showMapType() {
        val labels = arrayOf("Standard (OpenStreetMap)", "Satellite", "Topo (OpenTopoMap)")
        AlertDialog.Builder(this)
            .setTitle("Map type")
            .setItems(labels) { _, i ->
                prefs.edit().putInt("maptype", i).apply()
                applyMapType()
            }
            .show()
    }

    private fun applyKeepOn() {
        if (prefs.getBoolean("keepon", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- route (waypoints) ----------
    private fun addWaypoint(p: GeoPoint) {
        waypoints.add(p)
        val m = Marker(map).apply {
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Point ${waypoints.size}"
            icon?.mutate()?.setTint(Color.BLUE)
            position = p
        }
        wpMarkers.add(m)
        map.overlays.add(m)
        redrawRoute()
        toast("Route point ${waypoints.size} add hua")
    }

    private fun redrawRoute() {
        routeLine?.let { map.overlays.remove(it) }
        routeLine = null
        if (waypoints.isNotEmpty()) {
            val pts = ArrayList<GeoPoint>()
            pts.add(GeoPoint(lat, lng))
            pts.addAll(waypoints)
            val pl = Polyline()
            pl.outlinePaint.color = Color.BLUE
            pl.outlinePaint.strokeWidth = 6f
            pl.setPoints(pts)
            map.overlays.add(1, pl)
            routeLine = pl
        }
        map.invalidate()
    }

    private fun clearRoute() {
        walking = false
        for (m in wpMarkers) map.overlays.remove(m)
        wpMarkers.clear()
        waypoints.clear()
        updateWalkBtn()
        redrawRoute()
        toast("Route cleared")
    }

    private fun toggleWalk() {
        if (waypoints.isEmpty()) {
            toast("Long-press on map first to add route points")
            return
        }
        walking = !walking
        updateWalkBtn()
        if (walking) ensureTicking()
    }

    private fun updateWalkBtn() {
        btnWalk.text = if (walking) "Stop walk" else "Walk on route"
    }

    private fun toggleMovePanel() {
        panelMove.visibility = if (panelMove.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ---------- joystick / walk / roam ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun bindJoy(id: Int, n: Double, e: Double) {
        findViewById<Button>(id).setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    joyN = n; joyE = e
                    v.isPressed = true
                    ensureTicking()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    joyN = 0.0; joyE = 0.0
                    v.isPressed = false
                }
            }
            true
        }
    }

    private fun ensureTicking() {
        if (!ticking) { ticking = true; ui.post(moveTick) }
    }

    private fun setRoam(on: Boolean) {
        roam = on
        roamCenter = if (on) GeoPoint(lat, lng) else null
        roamTarget = null
        if (on) { toast("Roam mode ON"); ensureTicking() } else toast("Roam mode OFF")
    }

    private fun showRoamRadius() {
        val v = intArrayOf(10, 30, 50, 100, 200)
        AlertDialog.Builder(this)
            .setTitle("Roam radius")
            .setItems(arrayOf("10 m", "30 m", "50 m", "100 m", "200 m")) { _, i ->
                roamRadius = v[i]
                toast("Roam radius: ${v[i]} m")
            }
            .show()
    }

    private fun showSpeedPresets() {
        val labels = arrayOf("Walk (5 km/h)", "Run (10 km/h)", "Cycle (20 km/h)", "Bike (40 km/h)", "Car (60 km/h)", "Fast car (100 km/h)")
        val v = intArrayOf(5, 10, 20, 40, 60, 100)
        AlertDialog.Builder(this)
            .setTitle("Speed preset")
            .setItems(labels) { _, i -> seek.progress = v[i] - 1 }
            .show()
    }

    private fun stepMove(): Boolean {
        val meters = speedKmh / 3.6 * 0.5
        if (joyN != 0.0 || joyE != 0.0) {
            moveBy(joyN, joyE, meters)
            return true
        }
        if (walking) {
            if (waypoints.isEmpty()) { walking = false; updateWalkBtn(); return false }
            val d = waypoints[0]
            val dist = distanceM(lat, lng, d.latitude, d.longitude)
            if (dist < 2.0) {
                if (loopRoute) {
                    if (waypoints.size > 1) {
                        waypoints.add(waypoints.removeAt(0))
                        wpMarkers.add(wpMarkers.removeAt(0))
                    }
                } else {
                    waypoints.removeAt(0)
                    val m = wpMarkers.removeAt(0)
                    map.overlays.remove(m)
                    if (waypoints.isEmpty()) {
                        walking = false
                        updateWalkBtn()
                        redrawRoute()
                        toast("Route completed")
                        return false
                    }
                }
                redrawRoute()
                return true
            }
            moveBy(d.latitude - lat, (d.longitude - lng) * cos(Math.toRadians(lat)), min(meters, dist))
            return true
        }
        if (roam) {
            val c = roamCenter ?: GeoPoint(lat, lng).also { roamCenter = it }
            var t = roamTarget
            if (t == null || distanceM(lat, lng, t.latitude, t.longitude) < 2.0) {
                val ang = Math.random() * 2 * PI
                val r = Math.random() * roamRadius
                t = GeoPoint(
                    c.latitude + r * cos(ang) / 111320.0,
                    c.longitude + r * sin(ang) / (111320.0 * cos(Math.toRadians(c.latitude)).coerceAtLeast(0.01))
                )
                roamTarget = t
            }
            val dist = distanceM(lat, lng, t.latitude, t.longitude)
            moveBy(t.latitude - lat, (t.longitude - lng) * cos(Math.toRadians(lat)), min(min(meters, 0.5), dist))
            return true
        }
        return false
    }

    private fun moveBy(n: Double, e: Double, meters: Double) {
        val len = sqrt(n * n + e * e)
        if (len == 0.0) return
        val dLat = (n / len) * meters / 111320.0
        val dLng = (e / len) * meters / (111320.0 * cos(Math.toRadians(lat)).coerceAtLeast(0.01))
        val nl = (lat + dLat).coerceIn(-85.0, 85.0)
        var ng = lng + dLng
        if (ng > 180.0) ng -= 360.0
        if (ng < -180.0) ng += 360.0
        val bearing = (Math.toDegrees(atan2(e, n)) + 360.0) % 360.0
        totalM += meters
        prefs.edit()
            .putFloat("bearing", bearing.toFloat())
            .putFloat("speed", (min(speedKmh / 3.6, if (roam && !walking && joyN == 0.0 && joyE == 0.0) 0.5 else 1000.0)).toFloat())
            .apply()
        setPoint(nl, ng, true)
        if (waypoints.isNotEmpty()) redrawRoute()
    }

    private fun distanceM(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(c - a)
        val dLng = Math.toRadians(d - b)
        val x = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(a)) * cos(Math.toRadians(c)) * sin(dLng / 2) * sin(dLng / 2)
        return 2 * r * atan2(sqrt(x), sqrt(1 - x))
    }

    private fun showDistance() {
        val txt = if (totalM >= 1000) String.format(Locale.US, "%.2f km", totalM / 1000)
        else String.format(Locale.US, "%.0f m", totalM)
        AlertDialog.Builder(this)
            .setTitle("Session distance")
            .setMessage("In this session the location moved $txt.")
            .setPositiveButton("Reset") { _, _ -> totalM = 0.0 }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- lock ON / OFF ----------
    private fun toggleLock() {
        if (MockLocationService.running) {
            stopService(Intent(this, MockLocationService::class.java))
            ui.postDelayed({ refreshUi() }, 400)
            return
        }
        val need = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(need.toTypedArray())
    }

    private fun startMock() {
        MockLocationService.lastError = null
        addHistory()
        ContextCompat.startForegroundService(this, Intent(this, MockLocationService::class.java))
        ui.postDelayed({
            if (MockLocationService.lastError == "mock_not_selected") showMockHelp()
            refreshUi()
        }, 1200)
    }

    private fun showMockHelp() {
        AlertDialog.Builder(this)
            .setTitle("Select mock location app")
            .setMessage(
                "1. Open Developer options\n" +
                "2. Tap \"Select mock location app\"\n" +
                "3. Choose FakeGPS Lock\n" +
                "4. Come back and turn lock ON\n\n" +
                "Don't see Developer options? Settings → About phone → tap Build number 7 times."
            )
            .setPositiveButton("Open Developer options") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
            }
            .setNegativeButton("Later", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun isMockApp(): Boolean = try {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow("android:mock_location", Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    private fun showSetupCheck() {
        val loc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val notif = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        val mock = isMockApp()
        val upd = !UPDATE_REPO.startsWith("USERNAME")
        fun s(b: Boolean) = if (b) "OK" else "NO"
        AlertDialog.Builder(this)
            .setTitle("Setup check")
            .setMessage(
                "Location permission: ${s(loc)}\n" +
                "Notification permission: ${s(notif)}\n" +
                "Mock location app select: ${s(mock)}\n" +
                "Update repo set: ${s(upd)}"
            )
            .setPositiveButton("Developer options") { _, _ -> showMockHelp() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openBatterySettings() {
        try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        catch (e: Exception) { toast("Could not open settings") }
    }

    private fun refreshUi() {
        val coords = String.format(Locale.US, "%.5f, %.5f", lat, lng)
        if (MockLocationService.running) {
            btnLock.text = "LOCK ON  (tap to stop)"
            btnLock.setBackgroundColor(ContextCompat.getColor(this, R.color.on_green))
            tvStatus.text = "LOCKED: $coords"
        } else {
            btnLock.text = "LOCK LOCATION : ON"
            btnLock.setBackgroundColor(ContextCompat.getColor(this, R.color.off_red))
            tvStatus.text = "OFF  |  Selected: $coords"
        }
        btnLock.setTextColor(Color.WHITE)
    }

    // ---------- accuracy / altitude / timer ----------
    private fun showAccuracy() {
        val v = intArrayOf(1, 3, 5, 10, 20)
        AlertDialog.Builder(this)
            .setTitle("GPS accuracy")
            .setItems(arrayOf("1 m", "3 m (default)", "5 m", "10 m", "20 m")) { _, i ->
                prefs.edit().putInt("acc", v[i]).apply()
                toast("Accuracy: ${v[i]} m")
            }
            .show()
    }

    private fun showAltitude() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        input.setText(prefs.getInt("alt", 0).toString())
        AlertDialog.Builder(this)
            .setTitle("Altitude (meter)")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val a = input.text.toString().toIntOrNull()
                if (a == null) toast("Enter a valid number")
                else { prefs.edit().putInt("alt", a).apply(); toast("Altitude: $a m") }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showTimer() {
        val labels = arrayOf("Never", "15 minutes", "30 minutes", "1 hour", "2 hours")
        val mins = intArrayOf(0, 15, 30, 60, 120)
        AlertDialog.Builder(this)
            .setTitle("Auto-stop timer (applies next time lock is ON)")
            .setItems(labels) { _, i ->
                prefs.edit().putInt("autostop", mins[i]).apply()
                toast("Timer: " + labels[i])
            }
            .show()
    }

    // ---------- favorites ----------
    private fun favs(): JSONArray = JSONArray(prefs.getString("favs", "[]"))

    private fun saveFavorite() {
        val input = EditText(this).apply { hint = "Name (e.g. Home, Office)" }
        AlertDialog.Builder(this)
            .setTitle("Save favorite")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().ifBlank { "Location" }
                val arr = favs()
                arr.put(JSONObject().put("n", name).put("la", lat).put("ln", lng))
                prefs.edit().putString("favs", arr.toString()).apply()
                toast("Saved: $name")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFavorites() {
        val arr = favs()
        if (arr.length() == 0) { toast("No favorites yet"); return }
        val names = Array(arr.length()) { arr.getJSONObject(it).getString("n") }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Favorites (tap: go, long-press: delete)")
            .setItems(names) { _, i ->
                val o = arr.getJSONObject(i)
                goTo(o.getDouble("la"), o.getDouble("ln"))
            }
            .setNegativeButton("Close", null)
            .create()
        dlg.setOnShowListener {
            dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->
                arr.remove(pos)
                prefs.edit().putString("favs", arr.toString()).apply()
                dlg.dismiss()
                toast("Deleted")
                showFavorites()
                true
            }
        }
        dlg.show()
    }

    private fun exportFavorites() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("favorites", favs().toString()))
        toast("Favorites copied to clipboard")
    }

    private fun importFavorites() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val incoming = JSONArray(text)
            val arr = favs()
            for (i in 0 until incoming.length()) {
                val o = incoming.getJSONObject(i)
                arr.put(JSONObject().put("n", o.getString("n")).put("la", o.getDouble("la")).put("ln", o.getDouble("ln")))
            }
            prefs.edit().putString("favs", arr.toString()).apply()
            toast("${incoming.length()} favorites imported")
        } catch (e: Exception) {
            toast("No valid favorites found in clipboard")
        }
    }

    // ---------- history ----------
    private fun addHistory() {
        val arr = JSONArray(prefs.getString("hist", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("t", System.currentTimeMillis()).put("la", lat).put("ln", lng))
        for (i in 0 until minOf(arr.length(), 9)) out.put(arr.getJSONObject(i))
        prefs.edit().putString("hist", out.toString()).apply()
    }

    private fun showHistory() {
        val arr = JSONArray(prefs.getString("hist", "[]"))
        if (arr.length() == 0) { toast("History is empty"); return }
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
        val items = Array(arr.length()) {
            val o = arr.getJSONObject(it)
            String.format(Locale.US, "%.5f, %.5f", o.getDouble("la"), o.getDouble("ln")) +
                "   (" + fmt.format(Date(o.getLong("t"))) + ")"
        }
        AlertDialog.Builder(this)
            .setTitle("Recent history")
            .setItems(items) { _, i ->
                val o = arr.getJSONObject(i)
                goTo(o.getDouble("la"), o.getDouble("ln"))
            }
            .setNeutralButton("Clear") { _, _ -> prefs.edit().remove("hist").apply() }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- share / tools ----------
    private fun copyCoords() {
        val text = String.format(Locale.US, "%.6f,%.6f", lat, lng)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("coords", text))
        toast("Copied: $text")
    }

    private fun shareLink() {
        val link = String.format(Locale.US, "https://www.google.com/maps?q=%.6f,%.6f", lat, lng)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, link)
        startActivity(Intent.createChooser(i, "Share location"))
    }

    private fun openMaps() {
        val uri = Uri.parse(String.format(Locale.US, "geo:%.6f,%.6f?q=%.6f,%.6f", lat, lng, lat, lng))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (e: Exception) { toast("Maps app not found") }
    }

    private fun showHowTo() {
        AlertDialog.Builder(this)
            .setTitle("How to use")
            .setMessage(
                "1. Tap on the map or search a place name.\n" +
                "2. Tap LOCK LOCATION. First time you must select the mock location app.\n" +
                "3. To move, open the Move panel: use joystick or route walk.\n" +
                "4. For a route, long-press on map to add points, then start walk.\n" +
                "5. While lock is ON, map taps are disabled so the location does not move by mistake."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------- in-app update (GitHub Releases) ----------
    private fun checkUpdate(silent: Boolean) {
        if (UPDATE_REPO.startsWith("USERNAME")) {
            if (!silent) toast("Set UPDATE_REPO in MainActivity.kt")
            return
        }
        thread {
            try {
                val c = URL("https://api.github.com/repos/$UPDATE_REPO/releases/latest")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val newVer = j.getString("tag_name").removePrefix("v").toInt()
                val assets = j.getJSONArray("assets")
                var url: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
                }
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread
                    if (url != null && newVer > BuildConfig.VERSION_CODE) showUpdate(newVer, url)
                    else if (!silent) toast("App is up to date")
                }
            } catch (e: Exception) {
                if (!silent) runOnUiThread { toast("Update check failed: ${e.message}") }
            }
        }
    }

    private fun showUpdate(ver: Int, url: String) {
        AlertDialog.Builder(this)
            .setTitle("Naya update available")
            .setMessage("Version $ver is available. Download and install it.")
            .setPositiveButton("Update") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); map.onResume(); refreshUi() }
    override fun onPause() { super.onPause(); map.onPause() }
    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        prefs.edit().putFloat("speed", 0f).apply()
        super.onDestroy()
    }
}
