package com.fakegps.lock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Random
import kotlin.math.cos

class MockLocationService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var lastError: String? = null
        const val ACTION_STOP = "com.fakegps.lock.STOP"
        private const val CHANNEL = "fakegps_lock"
        private const val NOTIF_ID = 1001
    }

    private lateinit var lm: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    // GPS + NETWORK cover most apps; FUSED is used by Google Play Services apps
    private val providers = listOf(
        LocationManager.GPS_PROVIDER,
        LocationManager.NETWORK_PROVIDER
    )

    private val tick = object : Runnable {
        override fun run() {
            if (running) {
                push()
                handler.postDelayed(this, 800)
            }
        }
    }

    private val autoStop = Runnable {
        Toast.makeText(this, "Auto-stop: lock turned OFF", Toast.LENGTH_LONG).show()
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startInForeground()

        if (!running) {
            try {
                lm = getSystemService(LOCATION_SERVICE) as LocationManager
                for (p in providers) {
                    try {
                        lm.removeTestProvider(p)
                    } catch (_: Exception) {
                    }
                    try {
                        lm.addTestProvider(
                            p,
                            false, // requiresNetwork
                            false, // requiresSatellite
                            false, // requiresCell
                            false, // hasMonetaryCost
                            true,  // supportsAltitude
                            true,  // supportsSpeed
                            true,  // supportsBearing
                            Criteria.POWER_LOW,
                            Criteria.ACCURACY_FINE
                        )
                        lm.setTestProviderEnabled(p, true)
                    } catch (e: SecurityException) {
                        lastError = "mock_not_selected"
                        Toast.makeText(
                            this,
                            "Select this app in Developer options → Mock location app",
                            Toast.LENGTH_LONG
                        ).show()
                        stopSelf()
                        return START_NOT_STICKY
                    } catch (e: IllegalArgumentException) {
                        // provider already exists — try enable only
                        try {
                            lm.setTestProviderEnabled(p, true)
                        } catch (_: Exception) {
                        }
                    }
                }
                running = true
                lastError = null
                handler.post(tick)
                val mins = getSharedPreferences("fakegps", MODE_PRIVATE).getInt("autostop", 0)
                if (mins > 0) {
                    handler.postDelayed(autoStop, mins * 60_000L)
                }
            } catch (e: SecurityException) {
                lastError = "mock_not_selected"
                Toast.makeText(
                    this,
                    "Select this app in Developer options → Mock location app",
                    Toast.LENGTH_LONG
                ).show()
                stopSelf()
            } catch (e: Exception) {
                lastError = e.message ?: "error"
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun push() {
        if (!::lm.isInitialized) return
        val prefs = getSharedPreferences("fakegps", MODE_PRIVATE)
        var la = prefs.getString("lat", "28.6139")!!.toDouble()
        var ln = prefs.getString("lng", "77.2090")!!.toDouble()
        val spd = prefs.getFloat("speed", 0f)
        val brg = prefs.getFloat("bearing", 0f)
        var acc = prefs.getInt("acc", 3).toFloat()
        var alt = prefs.getInt("alt", 0).toDouble()

        if (prefs.getBoolean("jitter", false)) {
            la += rnd.nextGaussian() * 1.2 / 111320.0
            ln += rnd.nextGaussian() * 1.2 / (111320.0 * cos(Math.toRadians(la)).coerceAtLeast(0.01))
            acc += rnd.nextFloat() * 3f
            alt += rnd.nextGaussian() * 2.0
        }

        for (p in providers) {
            try {
                val loc = Location(p).apply {
                    latitude = la
                    longitude = ln
                    altitude = alt
                    accuracy = acc
                    speed = spd
                    bearing = brg
                    time = System.currentTimeMillis()
                    elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        bearingAccuracyDegrees = 1f
                        speedAccuracyMetersPerSecond = 0.5f
                        verticalAccuracyMeters = acc
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        // Android 12+
                        isMock = true
                    }
                }
                lm.setTestProviderLocation(p, loc)
            } catch (_: Exception) {
            }
        }
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL,
                "Location Lock",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps fake GPS running"
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, MockLocationService::class.java).setAction(ACTION_STOP),
            flags
        )

        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("FakeGPS Lock ON")
            .setContentText("Location is locked — tap STOP to turn off")
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()

        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (e: Exception) {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(autoStop)
        running = false
        if (::lm.isInitialized) {
            for (p in providers) {
                try {
                    lm.setTestProviderEnabled(p, false)
                } catch (_: Exception) {
                }
                try {
                    lm.removeTestProvider(p)
                } catch (_: Exception) {
                }
            }
        }
        super.onDestroy()
    }
}
